var express=require("express")
var app=new express()
app.get("/",(req,res)=>{
    res.write("First get Request")
    res.end()
})
app.post("/",(req,res)=>{
    res.write("First post Request")
    res.end()
})
app.put("/",(req,res)=>{
    res.write("First put Request")
    res.end()
})
app.delete("/",(req,res)=>{
    res.write("First delete Request")
    res.end()
})
app.listen(8000,()=>{
    console.log("Server Started Successfully...")
})